// Runs on every site (broad host access; the user can revoke per-site via Chrome). It stays QUIET unless
// there's something worth flagging: on a known broker it offers autofill for the opt-out form; on a social
// site or a page with an account form it shows a light identity tip; on ordinary pages it shows nothing.
// Honest — it states only what we KNOW (host in catalog / a form is present), never "your data is here".
// Everything is local; the member completes any CAPTCHA / email / phone confirmation themselves.
(function () {
  if (window.__idlPanelMounted) return;
  if (sessionStorage.getItem('idlPanelDismissed') === '1') return;

  const recipe = (window.IDL_matchRecipe && window.IDL_matchRecipe(location.host)) || null; // real broker match or null
  const cls = (window.IDL_classify && window.IDL_classify(location.host)) || { kind: 'other', name: location.host };
  const sig = pageSignals();
  const insight = (window.IDL_pageInsight && window.IDL_pageInsight(cls, sig)) || null;

  // Show nothing on ordinary pages (no broker, and nothing notable) — don't nag.
  if (!recipe && (!insight || insight.tone === 'muted')) return;
  window.__idlPanelMounted = true;

  let identity = {};
  let managedKeys = [];
  try {
    chrome.storage.local.get(['idlIdentity', 'idlManagedSourceKeys', 'idlUserId'], (r) => {
      identity = (r && r.idlIdentity) || {};
      managedKeys = (r && r.idlManagedSourceKeys) || [];
      maybeReportReappearance(r && r.idlUserId);
      mount();
    });
  } catch { mount(); }

  // ── Reappearance detection (in-session, first-party) ────────────────────────
  // Only for brokers the member has ACTIVELY opted out of (managedKeys), and only on an ELEMENT-LEVEL match
  // (their name co-occurring with a 2nd identifier inside one listing card) — a page-wide name match is
  // meaningless here because the broker echoes the searched name. We SUSPECT, the backend never asserts.
  const sldToSourceKey = (host) => {
    const h = String(host || '').toLowerCase().replace(/^www\./, '');
    const parts = h.split('.').filter(Boolean);
    return parts.length >= 2 ? parts[parts.length - 2] : h;
  };
  const digitsOnly = (s) => String(s || '').replace(/\D/g, '');
  function detectListing(id) {
    const first = (id.firstName || '').toLowerCase().trim();
    const last = (id.lastName || '').toLowerCase().trim();
    const full = (id.name || '').toLowerCase().trim();
    const city = (id.city || '').toLowerCase().trim();
    const state = (id.state || '').toLowerCase().trim();
    const age = id.age ? String(id.age) : '';
    const phone = digitsOnly(id.phone);
    const lastOk = last.length >= 3;
    const fullOk = full.length >= 5;
    if (!lastOk && !fullOk) return null;
    const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const stateRe = state.length >= 2 ? new RegExp('\\b' + esc(state) + '\\b') : null;
    const ageRe = age ? new RegExp('\\b' + age + '\\b') : null;
    let scanned = 0;
    for (const el of document.querySelectorAll('article,li,tr,section,div')) {
      if (scanned++ > 4000) break;
      const txt = (el.textContent || '').toLowerCase();
      if (txt.length < 6 || txt.length > 800) continue; // card-sized only, not the whole page
      const hasName = (fullOk && txt.includes(full)) || (first && lastOk && txt.includes(first) && txt.includes(last));
      if (!hasName) continue;
      const mCity = !!(city.length >= 3 && txt.includes(city));
      const mState = !!(stateRe && stateRe.test(txt));
      const mAge = !!(ageRe && ageRe.test(txt));
      const mPhone = !!(phone.length >= 7 && digitsOnly(txt).includes(phone));
      if (mCity || mState || mAge || mPhone) return { name: true, city: mCity, state: mState, age: mAge, phone: mPhone };
    }
    return null;
  }
  // Did the member actually search themselves here? Absence of a listing only means "removed" if a search
  // for this person ran — otherwise a bare homepage visit would read as removed. Evidence: name in the
  // URL/title, a search box carrying the name, or an explicit "no results" message.
  function searchedForMember(id) {
    const first = (id.firstName || '').toLowerCase().trim();
    const last = (id.lastName || '').toLowerCase().trim();
    if (last.length < 3) return null;
    const hay = (location.href + ' ' + (document.title || '')).toLowerCase();
    if (hay.includes(last) && (!first || hay.includes(first))) return 'url';
    let inInput = false;
    document.querySelectorAll('input[type=text],input[type=search],input:not([type])').forEach((i) => {
      const v = (i.value || '').toLowerCase(); if (v && v.includes(last)) inInput = true;
    });
    if (inInput) return 'input';
    const body = (document.body && document.body.textContent || '').toLowerCase();
    if (body.length > 200 && /no results|no records|0 results|couldn.?t find|no matches|nothing found/.test(body)) return 'no_results';
    return null;
  }

  let detection = null; // computed once, reused by the panel note
  function maybeReportReappearance(userId) {
    if (window.__idlReported) return;
    const candidate = sldToSourceKey(location.host);
    if (!Array.isArray(managedKeys) || managedKeys.indexOf(candidate) === -1) return; // not a managed broker
    detection = detectListing(identity);
    const base = { sourceKey: candidate, host: location.host, email: identity.email || '' };
    let payload = null;
    // App-initiated sweep (we navigated here with the name in the URL) — so name-in-URL is NOT independent
    // evidence of a real results page. Require the broker's OWN "no results" text before calling it removed.
    const appInitiated = /(^|[#&])idl-recheck\b/.test(location.hash);
    if (detection) {
      payload = { ...base, signal: 'present', matched: detection };
    } else {
      // Listing not found — only report a possible REMOVAL if a search for this person actually ran.
      const context = searchedForMember(identity);
      const ok = appInitiated ? context === 'no_results' : !!context;
      if (ok) payload = { ...base, signal: 'absent', context };
    }
    if (!payload) return;
    window.__idlReported = true;
    try { chrome.runtime.sendMessage({ type: 'reportDetection', userId, payload }); } catch { /* ignore */ }
  }

  function pageSignals() {
    let hasPassword = false, hasEmailField = false;
    document.querySelectorAll('input').forEach((i) => {
      const t = (i.type || '').toLowerCase();
      if (t === 'password') hasPassword = true;
      const h = ((i.name || '') + (i.id || '') + (i.placeholder || '') + (i.autocomplete || '')).toLowerCase();
      if (t === 'email' || /e-?mail/.test(h)) hasEmailField = true;
    });
    return { hasPassword, hasEmailField };
  }

  // ── Autofill engine (broker forms) ──────────────────────────────────────────
  function setNativeValue(el, value) {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype
      : el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) desc.set.call(el, value); else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function names(id) {
    const parts = String(id.name || '').trim().split(/\s+/).filter(Boolean);
    return {
      firstName: id.firstName || parts[0] || '',
      lastName: id.lastName || (parts.length > 1 ? parts[parts.length - 1] : '') || '',
      fullName: id.name || [id.firstName, id.lastName].filter(Boolean).join(' '),
    };
  }
  function fieldHint(el) {
    const bits = [el.name, el.id, el.placeholder, el.getAttribute && el.getAttribute('aria-label'), el.getAttribute && el.getAttribute('autocomplete')];
    try { if (el.id) { const l = document.querySelector('label[for="' + CSS.escape(el.id) + '"]'); if (l) bits.push(l.textContent); } } catch { /* ignore */ }
    const p = el.closest && el.closest('label'); if (p) bits.push(p.textContent);
    return bits.filter(Boolean).join(' ').toLowerCase();
  }
  function matchers(id) {
    const n = names(id);
    return [
      { re: /e-?mail/, get: () => id.email },
      { re: /first.?name|fname|given/, get: () => n.firstName },
      { re: /last.?name|lname|surname|family/, get: () => n.lastName },
      { re: /zip|postal/, get: () => id.zip },
      { re: /city|town/, get: () => id.city },
      { re: /state|province|region/, get: () => id.state },
      { re: /street|address(?!.*email)|addr(?![a-z]*email)/, get: () => id.address },
      { re: /phone|mobile|\btel\b/, get: () => id.phone },
      { re: /full.?name|your.?name|(^|[^a-z])name([^a-z]|$)/, get: () => n.fullName },
    ];
  }
  function fillSelect(el, value) {
    const v = String(value || '').toLowerCase();
    for (const opt of el.options) { const t = (opt.value + ' ' + opt.textContent).toLowerCase(); if (v && t.includes(v)) { setNativeValue(el, opt.value); return true; } }
    return false;
  }
  function autofill() {
    const M = matchers(identity);
    let filled = 0;
    document.querySelectorAll('input, textarea, select').forEach((el) => {
      if (el.disabled || el.readOnly || el.offsetParent === null) return;
      const type = (el.type || '').toLowerCase();
      if (['hidden', 'password', 'submit', 'button', 'checkbox', 'radio', 'file', 'search'].includes(type)) return;
      if (el.value && el.tagName !== 'SELECT') return;
      const hint = fieldHint(el); if (!hint) return;
      const m = M.find((x) => x.re.test(hint)); if (!m) return;
      const value = (m.get() || '').toString(); if (!value) return;
      if (el.tagName === 'SELECT') { if (fillSelect(el, value)) filled++; } else { setNativeValue(el, value); filled++; }
    });
    return filled;
  }

  // ── Panel ───────────────────────────────────────────────────────────────────
  function mount() {
    const hasId = !!(identity && (identity.name || identity.firstName || identity.email));
    const wrap = document.createElement('div');
    wrap.id = 'idl-optout-panel';
    // In-session monitoring: element-level match (name + a 2nd identifier in one listing card) — the honest
    // re-check that beats the anti-bot wall (it's the member's own browser). `detection` is computed above;
    // fall back to a fresh element scan if the storage callback hadn't run yet.
    const stillListed = !!(recipe && (detection || detectListing(identity)));

    if (recipe) {
      wrap.innerHTML = `
        <div class="idl-hd"><span class="idl-logo">IDLookup</span><button class="idl-x" title="Hide">×</button></div>
        <div class="idl-title">Remove yourself from ${esc(recipe.name)}</div>
        ${stillListed ? `<div class="idl-note" style="background:#fef2f2;border-color:#fecaca;color:#991b1b">⚠ Your name appears on this page — you may still be listed here.</div>` : ''}
        ${recipe.verification ? `<div class="idl-meta">🔐 ${esc(recipe.verification)}</div>` : ''}
        ${recipe.note ? `<div class="idl-note">💡 ${esc(recipe.note)}</div>` : ''}
        ${hasId
          ? `<button class="idl-fill">Autofill my details</button>
             <div class="idl-status" aria-live="polite"></div>
             <div class="idl-hint">Then solve any CAPTCHA and click the confirmation email — those steps have to be you.</div>`
          : `<div class="idl-hint">Sign in at idlookup.ai to sync your details, or add them in the IDLookup extension.</div>`}`;
    } else {
      wrap.innerHTML = `
        <div class="idl-hd"><span class="idl-logo">IDLookup</span><button class="idl-x" title="Hide">×</button></div>
        <div class="idl-title">${esc(insight.title)}</div>
        <div class="idl-meta">${esc(insight.body)}</div>`;
    }
    document.body.appendChild(wrap);
    wrap.querySelector('.idl-x').addEventListener('click', () => { try { sessionStorage.setItem('idlPanelDismissed', '1'); } catch { /* ignore */ } wrap.remove(); });
    const fill = wrap.querySelector('.idl-fill');
    if (fill) fill.addEventListener('click', () => {
      const n = autofill();
      const s = wrap.querySelector('.idl-status');
      s.textContent = n ? `Filled ${n} field${n === 1 ? '' : 's'}. Review, then submit + verify.` : 'No matching fields here yet — the form may load after you find your listing.';
      s.className = 'idl-status ' + (n ? 'ok' : 'warn');
    });
  }
  function esc(s) { return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
})();
