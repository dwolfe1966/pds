import React from 'react';
import { Link, useLocation, useSearchParams } from 'react-router-dom';
import styles from './Footer.module.css';
import BrandLogo from './BrandLogo';
import { useBrand } from '../services/brand';
import { useCampaign } from '../context/CampaignContext';
import { SELF_CHROME_PREFIXES, THEMED_FUNNEL_PREFIXES, funnelThemeActive } from './Header';

// Signup-teaser variants that render their own in-palette footer (self-contained,
// inmate-focused). The green global footer is suppressed for these so it doesn't clash.
const SELF_FOOTER_TEASER_VARIANTS = ['i', 'j'];

const Footer = () => {
  const brand = useBrand();
  const { pathname } = useLocation();
  const [searchParams] = useSearchParams();
  const campaign = useCampaign();
  // Self-chrome color landings render their own in-palette footer (ColorLandingFooter);
  // suppress the green global footer there so it doesn't clash with the landing's scheme.
  if (SELF_CHROME_PREFIXES.some((p) => pathname.startsWith(p))) return null;
  // Themed funnel pages (loader/results): suppress the green footer when a funnel theme is
  // active so it doesn't clash with the themed page. Green funnels keep it.
  if (funnelThemeActive() && THEMED_FUNNEL_PREFIXES.some((p) => pathname.startsWith(p))) return null;
  // Teaser pages (/search/:id): suppress the green footer only for variants that ship their
  // own (i/j). Other variants (incl. the live VariantA) keep the green footer's legal links.
  if (pathname.startsWith('/search/') && pathname !== '/search/all') {
    const v = (searchParams.get('v') || campaign?.detail?.variant || '').toLowerCase();
    if (SELF_FOOTER_TEASER_VARIANTS.includes(v)) return null;
  }
  return (
    <footer className={styles.footer}>
      <div className={styles.footerContent}>
        <div className={styles.footerGrid}>
          {/* Brand Section */}
          <div className={styles.brandSection}>
            <div style={{ marginBottom: '0.5rem' }}>
              <BrandLogo height={32} />
            </div>
            <h4>{brand.name}</h4>
            <p>
              Find people and monitor who searches for you. Access comprehensive public records and stay informed.
            </p>
          </div>

          {/* Legal Section — Refund policy folded into Terms; California Privacy
              folded into Privacy Policy (partner bug 25). */}
          <div>
            <h5 className={styles.sectionTitle}>Legal</h5>
            <div className={styles.sectionLinks}>
              {[
                { to: '/privacy', label: 'Privacy Policy' },
                { to: '/terms', label: 'Terms of Service' },
              ].map((link) => (
                <Link key={link.to} to={link.to} className={styles.sectionLink}>
                  {link.label}
                </Link>
              ))}
            </div>
          </div>

          {/* Resources Section */}
          <div>
            <h5 className={styles.sectionTitle}>Resources</h5>
            <div className={styles.sectionLinks}>
              {[
                { to: '/opt-out', label: 'Opt Out' },
                { to: '/unsubscribe', label: 'Unsubscribe' },
                { to: '/suppression-list', label: 'Suppression List' },
                { to: '/partner', label: 'Partner With Us' },
              ].map((link) => (
                <Link key={link.to} to={link.to} className={styles.sectionLink}>
                  {link.label}
                </Link>
              ))}
            </div>
          </div>

          {/* Support Section */}
          <div>
            <h5 className={styles.sectionTitle}>Support</h5>
            <div className={styles.sectionLinks}>
              {[
                { to: '/contact', label: 'Contact Us' },
                { to: '/about', label: 'About' },
              ].map((link) => (
                <Link key={link.to} to={link.to} className={styles.sectionLink}>
                  {link.label}
                </Link>
              ))}
            </div>
            <div className={styles.csSupportNote}>
              Our customer support team is available Monday&ndash;Friday, 9am&ndash;5pm ET.
              For account issues, billing questions, or data removal requests,
              please visit our <Link to="/contact" className={styles.csSupportLink}>contact page</Link>.
            </div>
          </div>
        </div>

        {/* Copyright Section */}
        <div className={styles.copyright}>
          <small className={styles.copyrightText}>
            © {new Date().getFullYear()} {brand.name}. All rights reserved.
          </small>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
